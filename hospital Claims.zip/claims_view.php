 <!-- Claims View -->
        <div class="card">
            <h2 class="card-title">Claims</h2>
            <?php if (isset($claim_added)): ?>
                <div class="success-message">Claim added successfully!</div>
            <?php endif; ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient</th>
                        <th>Diagnosis</th>
                        <th>Procedure</th>
                        <th>Total Amount</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($claims as $claim): ?>
                        <tr>
                            <td><?php echo $claim['id']; ?></td>
                            <td><?php echo $claim['firstname'] . ' ' . $claim['lastname']; ?></td>
                            <td><?php echo $claim['diagnosis']; ?></td>
                            <td><?php echo $claim['procedure_done']; ?></td>
                            <td>₱<?php echo number_format($claim['total_amount'], 2); ?></td>
                            <td>
                                <?php if ($claim['status'] == 'pending'): ?>
                                    <span class="status-pending">Pending</span>
                                <?php elseif ($claim['status'] == 'approved'): ?>
                                    <span class="status-approved">Approved</span>
                                <?php else: ?>
                                    <span class="status-denied">Denied</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="#">
                                    <button style="padding: 0.5rem 1rem;">View Details</button>
                                </a>
                                <?php if ($_SESSION['access_level'] == 'admin'): ?>
                                    <a href="#" style="margin-left: 0.5rem;">
                                        <button style="padding: 0.5rem 1rem; background-color: #5cb85c;">Approve</button>
                                    </a>
                                    <a href="#" style="margin-left: 0.5rem;">
                                        <button style="padding: 0.5rem 1rem; background-color: #d9534f;">Deny</button>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>