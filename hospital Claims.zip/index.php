<?php
session_start();

// Database configuration
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'hospital_billing';

// Create database connection
$conn = new mysqli($db_host, $db_user, $db_pass);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if not exists
$sql = "CREATE DATABASE IF NOT EXISTS $db_name";
if ($conn->query($sql) === FALSE) {
    echo "Error creating database: " . $conn->error;
}

// Select the database
$conn->select_db($db_name);

// Create employees table
$sql = "CREATE TABLE IF NOT EXISTS employees (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(30) NOT NULL,
    password VARCHAR(255) NOT NULL,
    fullname VARCHAR(50) NOT NULL,
    position VARCHAR(30) NOT NULL,
    access_level ENUM('admin', 'staff') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($sql);

// Create patients table
$sql = "CREATE TABLE IF NOT EXISTS patients (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    firstname VARCHAR(30) NOT NULL,
    lastname VARCHAR(30) NOT NULL,
    age INT(3) NOT NULL,
    address TEXT NOT NULL,
    contact_number VARCHAR(15) NOT NULL,
    date_admitted DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($sql);

// Create claims table
$sql = "CREATE TABLE IF NOT EXISTS claims (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_id INT(6) UNSIGNED NOT NULL,
    diagnosis TEXT NOT NULL,
    procedure_done TEXT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    philhealth_benefit DECIMAL(10,2) NOT NULL,
    hospital_fee DECIMAL(10,2) NOT NULL,
    professional_fee DECIMAL(10,2) NOT NULL,
    date_processed DATE NOT NULL,
    processed_by INT(6) UNSIGNED NOT NULL,
    status ENUM('pending', 'approved', 'denied') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id),
    FOREIGN KEY (processed_by) REFERENCES employees(id)
)";
$conn->query($sql);

// Add sample admin if no employees exist
$check = "SELECT id FROM employees LIMIT 1";
$result = $conn->query($check);
if ($result->num_rows === 0) {
    $password = password_hash('admin123', PASSWORD_DEFAULT);
    $sql = "INSERT INTO employees (username, password, fullname, position, access_level) 
            VALUES ('admin', '$password', 'System Administrator', 'Admin', 'admin')";
    $conn->query($sql);
}

// Handle login
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $sql = "SELECT * FROM employees WHERE username = '$username'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $employee = $result->fetch_assoc();
        if (password_verify($password, $employee['password'])) {
            $_SESSION['user_id'] = $employee['id'];
            $_SESSION['username'] = $employee['username'];
            $_SESSION['fullname'] = $employee['fullname'];
            $_SESSION['position'] = $employee['position'];
            $_SESSION['access_level'] = $employee['access_level'];
            header("Location: index.php");
            exit();
        } else {
            $login_error = "Invalid username or password";
        }
    } else {
        $login_error = "Invalid username or password";
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

// Handle form submissions
if (isset($_POST['add_patient'])) {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $age = $_POST['age'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $date_admitted = $_POST['date_admitted'];
    
    $sql = "INSERT INTO patients (firstname, lastname, age, address, contact_number, date_admitted) 
            VALUES ('$firstname', '$lastname', '$age', '$address', '$contact', '$date_admitted')";
    $conn->query($sql);
    $patient_added = true;
}

if (isset($_POST['add_claim'])) {
    $patient_id = $_POST['patient_id'];
    $diagnosis = $_POST['diagnosis'];
    $procedure = $_POST['procedure'];
    $total_amount = $_POST['total_amount'];
    $philhealth = $_POST['philhealth'];
    $hospital_fee = $_POST['hospital_fee'];
    $professional_fee = $_POST['professional_fee'];
    $processed_by = $_SESSION['user_id'];
    
    $sql = "INSERT INTO claims (patient_id, diagnosis, procedure_done, total_amount, philhealth_benefit, hospital_fee, professional_fee, date_processed, processed_by) 
            VALUES ($patient_id, '$diagnosis', '$procedure', $total_amount, $philhealth, $hospital_fee, $professional_fee, CURDATE(), $processed_by)";
    $conn->query($sql);
    $claim_added = true;
}

// Get data for views
$patients = [];
$patients_result = $conn->query("SELECT * FROM patients");
if ($patients_result) {
    while ($row = $patients_result->fetch_assoc()) {
        $patients[] = $row;
    }
}

$claims = [];
$claims_result = $conn->query("SELECT c.id, p.firstname, p.lastname, c.diagnosis, c.procedure_done, c.total_amount, c.philhealth_benefit, c.hospital_fee, c.professional_fee, c.status 
                                FROM claims c 
                                JOIN patients p ON c.patient_id = p.id");
if ($claims_result) {
    while ($row = $claims_result->fetch_assoc()) {
        $claims[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dinagat District Hospital - MAIFFIPP Claims</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }
        header {
            background-color: #005b96;
            color: white;
            padding: 1rem 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        header h1 {
            margin: 0;
            font-size: 1.5rem;
        }
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .nav-links {
            display: flex;
            gap: 1rem;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        .nav-links a:hover {
            background-color: rgba(255,255,255,0.2);
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: white;
        }
        .logout-btn {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            cursor: pointer;
        }
        .logout-btn:hover {
            background-color: #c9302c;
        }
        .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 1.5rem;
            margin: 1rem 0;
        }
        .card-title {
            margin-top: 0;
            color: #005b96;
            border-bottom: 1px solid #eee;
            padding-bottom: 0.5rem;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }
        input, select, textarea {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }
        button {
            background-color: #005b96;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #003d66;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #005b96;
            color: white;
        }
        tr:hover {
            background-color: #f9f9f9;
        }
        .status-pending {
            color: #f0ad4e;
        }
        .status-approved {
            color: #5cb85c;
        }
        .status-denied {
            color: #d9534f;
        }
        .success-message {
            background-color: #dff0d8;
            color: #3c763d;
            padding: 1rem;
            border-radius: 4px;
            margin: 1rem 0;
        }
        .error-message {
            background-color: #f2dede;
            color: #a94442;
            padding: 1rem;
            border-radius: 4px;
            margin: 1rem 0;
        }
        .login-container {
            max-width: 400px;
            margin: 3rem auto;
            padding: 2rem;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .login-title {
            text-align: center;
            color: #005b96;
            margin-bottom: 2rem;
        }
        .footer {
            text-align: center;
            padding: 1rem 0;
            margin-top: 2rem;
            color: #777;
            border-top: 1px solid #eee;
        }
        .badge {
            display: inline-block;
            padding: 0.25em 0.4em;
            font-size: 75%;
            font-weight: 700;
            line-height: 1;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 0.25rem;
        }
        .badge-primary {
            color: #fff;
            background-color: #00ff22ff;
        }
        .badge-success {
            color: #fff;
            background-color: #28a745;
        }
        .badge-danger {
            color: #fff;
            background-color: #dc3545;
        }
        .badge-warning {
            color: #212529;
            background-color: #ffc107;
        }
    </style>
</head>
<body>
    <?php if (!isset($_SESSION['user_id'])): ?>
    <!-- Login Form -->
    <div class="login-container card">
        <h2 class="login-title">Dinagat District Hospital<br>Employee Login</h2>
        <?php if (isset($login_error)): ?>
            <div class="error-message"><?php echo $login_error; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="login">Login</button>
        </form>
    </div>
    <?php else: ?>
    <!-- Main Application -->
    <header>
        <div class="container">
            <nav>
                <h1>Dinagat District Hospital - MAIFFIPP Claims</h1>
                <div class="nav-links">
                    <a href="index.php">Dashboard</a>
                    <a href="index.php?view=patients">Patients</a>
                    <a href="index.php?view=claims">Claims</a>
                </div>
                <div class="user-info">
                    <span>Welcome, <?php echo $_SESSION['fullname']; ?> (<?php echo $_SESSION['position']; ?>)</span>
                    <a href="index.php?logout=1" class="logout-btn">Logout</a>
                </div>
            </nav>
        </div>
    </header>

    <main class="container">
        <?php
        $view = isset($_GET['view']) ? $_GET['view'] : 'dashboard';
        
        if ($view == 'dashboard') {
            include 'dashboard_view.php';
        } elseif ($view == 'patients') {
            include 'patients_view.php';
        } elseif ($view == 'claims') {
            include 'claims_view.php';
        } elseif ($view == 'add_patient') {
            include 'add_patient_view.php';
        } elseif ($view == 'add_claim') {
            include 'add_claim_view.php';
        }
        ?>

        <?php if (!file_exists("dashboard_view.php")): ?>
       
        <?php endif; ?>

        <?php if (!file_exists("patients_view.php")): ?>
        
        <?php endif; ?>

        <?php if (!file_exists("add_patient_view.php")): ?>
       
        <?php endif; ?>

        <?php if (!file_exists("claims_view.php")): ?>
       
        <?php endif; ?>

        <?php if (!file_exists("add_claim_view.php")): ?>
      
        <div class="card">
            <?php if (isset($_GET['patient_id'])): 
                $patient_id = $_GET['patient_id'];
                $sql = "SELECT * FROM patients WHERE id = $patient_id";
                $result = $conn->query($sql);
                $patient = $result->fetch_assoc();
            ?>
                <h2 class="card-title">Add Claim for <?php echo $patient['firstname'] . ' ' . $patient['lastname']; ?></h2>
            <?php else: ?>
                <h2 class="card-title">Add New Claim</h2>
            <?php endif; ?>
            
            <form method="POST" action="">
                <?php if (isset($patient_id)): ?>
                    <input type="hidden" name="patient_id" value="<?php echo $patient_id; ?>">
                <?php else: ?>
                    <div class="form-group">
                        <label for="patient_id">Patient</label>
                        <select id="patient_id" name="patient_id" required>
                            <option value="">Select Patient</option>
                            <?php foreach ($patients as $p): ?>
                                <option value="<?php echo $p['id']; ?>">
                                    <?php echo $p['firstname'] . ' ' . $p['lastname']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>
                
                <div class="form-group">
                    <label for="diagnosis">Diagnosis</label>
                    <textarea id="diagnosis" name="diagnosis" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label for="procedure">Procedure Done</label>
                    <textarea id="procedure" name="procedure" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label for="total_amount">Total Amount (₱)</label>
                    <input type="number" id="total_amount" name="total_amount" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="philhealth">PhilHealth Benefit (₱)</label>
                    <input type="number" id="philhealth" name="philhealth" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="hospital_fee">Hospital Fee (₱)</label>
                    <input type="number" id="hospital_fee" name="hospital_fee" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="professional_fee">Professional Fee (₱)</label>
                    <input type="number" id="professional_fee" name="professional_fee" step="0.01" required>
                </div>
                <button type="submit" name="add_claim">Submit Claim</button>
                <a href="index.php?view=claims" style="margin-left: 1rem;">
                    <button type="button">Cancel</button>
                </a>
            </form>
        </div>
        <?php endif; ?>
    </main>

    <footer class="footer container">
        <p>Dinagat District Hospital &copy; <?php echo date('Y'); ?> - MAIFFIPP Claims Processing System</p>
    </footer>
    <?php endif; ?>
</body>
</html>
