 <!-- Dashboard View -->
        <div class="card">
            <h2 class="card-title">Dashboard</h2>
            <div class="card-body">
                <div style="display: flex; gap: 1rem; margin-bottom: 2rem;">
                    <div class="card" style="flex: 1;">
                        <h3>Total Patients</h3>
                        <p style="font-size: 2rem; font-weight: bold;"><?php echo count($patients); ?></p>
                    </div>
                    <div class="card" style="flex: 1;">
                        <h3>Total Claims</h3>
                        <p style="font-size: 2rem; font-weight: bold;"><?php echo count($claims); ?></p>
                    </div>
                    <div class="card" style="flex: 1;">
                        <h3>Pending Claims</h3>
                        <p style="font-size: 2rem; font-weight: bold;">
                            <?php echo count(array_filter($claims, function($claim) { return $claim['status'] == 'pending'; })); ?>
                        </p>
                    </div>
                </div>

                <div class="card">
                    <h3>Recent Claims</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Patient</th>
                                <th>Diagnosis</th>
                                <th>Procedure</th>
                                <th>Total Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_slice($claims, 0, 5) as $claim): ?>
                                <tr>
                                    <td><?php echo $claim['firstname'] . ' ' . $claim['lastname']; ?></td>
                                    <td><?php echo $claim['diagnosis']; ?></td>
                                    <td><?php echo $claim['procedure_done']; ?></td>
                                    <td>₱<?php echo number_format($claim['total_amount'], 2); ?></td>
                                    <td>
                                        <?php if ($claim['status'] == 'pending'): ?>
                                            <span class="badge badge-warning">Pending</span>
                                        <?php elseif ($claim['status'] == 'approved'): ?>
                                            <span class="badge badge-success">Approved</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Denied</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>