<!-- Patients View -->
        <div class="card">
            <h2 class="card-title">Patients
                <a href="index.php?view=add_patient" style="float: right;">
                    <button>Add New Patient</button>
                </a>
            </h2>
            <?php if (isset($patient_added)): ?>
                <div class="success-message">Patient record added successfully!</div>
            <?php endif; ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Address</th>
                        <th>Contact</th>
                        <th>Date Admitted</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($patients as $patient): ?>
                        <tr>
                            <td><?php echo $patient['id']; ?></td>
                            <td><?php echo $patient['firstname'] . ' ' . $patient['lastname']; ?></td>
                            <td><?php echo $patient['age']; ?></td>
                            <td><?php echo $patient['address']; ?></td>
                            <td><?php echo $patient['contact_number']; ?></td>
                            <td><?php echo $patient['date_admitted']; ?></td>
                            <td>
                                <a href="index.php?view=add_claim&patient_id=<?php echo $patient['id']; ?>">
                                    <button style="padding: 0.5rem 1rem;">Add Claim</button>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>