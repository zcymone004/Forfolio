<!-- Add Patient View -->
        <div class="card">
            <h2 class="card-title">Add New Patient</h2>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="firstname">First Name</label>
                    <input type="text" id="firstname" name="firstname" required>
                </div>
                <div class="form-group">
                    <label for="lastname">Last Name</label>
                    <input type="text" id="lastname" name="lastname" required>
                </div>
                <div class="form-group">
                    <label for="age">Age</label>
                    <input type="number" id="age" name="age" required min="0" max="120">
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea id="address" name="address" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label for="contact">Contact Number</label>
                    <input type="tel" id="contact" name="contact" required>
                </div>
                <div class="form-group">
                    <label for="date_admitted">Date Admitted</label>
                    <input type="date" id="date_admitted" name="date_admitted" required>
                </div>
                <button type="submit" name="add_patient">Save Patient Record</button>
                <a href="index.php?view=patients" style="margin-left: 1rem;">
                    <button type="button">Cancel</button>
                </a>
            </form>
        </div>